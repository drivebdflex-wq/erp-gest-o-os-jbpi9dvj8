import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useToast } from '@/hooks/use-toast'
import { ServiceOrdersService } from '@/services/service-orders/service-orders.service'
import { ServiceOrder } from '@/services/service-orders/service-orders.types'
import {
  ServiceOrderChecklistsRepository,
  ChecklistItemsRepository,
} from '@/services/repositories/checklists.repository'
import { PhotosRepository } from '@/services/repositories/auxiliary.repository'
import { ChecklistsService } from '@/services/business/checklists.service'
import { CheckCircle2, Play, Camera, PenTool, ClipboardList, Box, Check } from 'lucide-react'
import useInventoryStore from '@/stores/useInventoryStore'
import useFinanceStore from '@/stores/useFinanceStore'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Trash2, Loader2 } from 'lucide-react'
import useAuthStore from '@/stores/useAuthStore'
import { supabase } from '@/lib/supabase/client'

export default function TechExecution() {
  // @ts-expect-error
  const user = useAuthStore?.((state: any) => state.user)
  const isAdmin =
    user?.role === 'admin' || user?.role === 'Administrator' || user?.role === 'admin_master'

  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { toast } = useToast()

  const { products, balances, consumeForOS } = useInventoryStore()
  const { addCost } = useFinanceStore()

  const [selectedMaterial, setSelectedMaterial] = useState<string>('')
  const [consumeQty, setConsumeQty] = useState<number>(1)

  const [order, setOrder] = useState<ServiceOrder | null>(null)
  const [loading, setLoading] = useState(true)
  const [checklists, setChecklists] = useState<any[]>([])
  const [photos, setPhotos] = useState<any[]>([])
  const [showDeleteAlert, setShowDeleteAlert] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    loadOrderData()
  }, [id])

  const handleDelete = async () => {
    if (!id) return
    setIsDeleting(true)
    try {
      await ServiceOrdersService.delete(id)
      window.dispatchEvent(new Event('service-order-deleted'))
      toast({ title: 'Sucesso', description: 'Service Order deleted successfully.' })
      navigate('/ordens')
    } catch (e: any) {
      toast({
        title: 'Erro',
        description: e.message || 'Falha ao excluir OS.',
        variant: 'destructive',
      })
    } finally {
      setIsDeleting(false)
      setShowDeleteAlert(false)
    }
  }

  const loadOrderData = async () => {
    if (!id) return
    setLoading(true)
    try {
      const data = await ServiceOrdersService.getServiceOrderById(id)
      setOrder(data)
      const allSoChecklists = await ServiceOrderChecklistsRepository.findAll()
      setChecklists(allSoChecklists.filter((c) => c.service_order_id === id))
      const { data: allPhotos } = await supabase
        .from('photos')
        .select('*')
        .eq('service_order_id', id)
      setPhotos(allPhotos || [])
    } catch (error) {
      toast({ title: 'Erro', description: 'OS não encontrada', variant: 'destructive' })
      navigate('/tech')
    } finally {
      setLoading(false)
    }
  }

  const handleStatusChange = async (newStatus: string) => {
    try {
      await ServiceOrdersService.updateServiceOrderStatus(id!, newStatus as any)
      toast({ title: 'Sucesso', description: `Status alterado para ${newStatus}` })
      loadOrderData()
    } catch (error: any) {
      toast({
        title: 'Atenção - Regra de Negócio',
        description: error.message,
        variant: 'destructive',
      })
    }
  }

  const mockCompleteChecklist = async (soChecklistId: string) => {
    try {
      const items = await ChecklistItemsRepository.findAll()
      const reqItems = items.filter((i) => i.is_required)
      for (const item of reqItems) {
        await ChecklistsService.addResponse({
          service_order_checklist_id: soChecklistId,
          checklist_item_id: item.id,
          response_boolean: true,
          response_number: 100,
        })
      }
      toast({ title: 'Sucesso', description: 'Checklist preenchido' })
      loadOrderData()
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  const uploadPhoto = async (e: React.ChangeEvent<HTMLInputElement>, type: string) => {
    const file = e.target.files?.[0]
    if (!file || !id) return

    setLoading(true)
    try {
      const fileExt = file.name.split('.').pop()
      const fileName = `${id}/${type}_${Math.random()}.${fileExt}`

      const { data, error } = await supabase.storage.from('photos').upload(fileName, file)
      if (error) throw error

      const { data: publicUrlData } = supabase.storage.from('photos').getPublicUrl(fileName)

      await supabase.from('photos').insert({
        service_order_id: id,
        type: type === 'service_order_initial' ? 'initial' : 'final',
        storage_url: publicUrlData.publicUrl,
        uploaded_by: user?.id,
      })

      toast({ title: 'Foto Adicionada', description: `Foto salva com sucesso.` })
      loadOrderData()
    } catch (error: any) {
      toast({ title: 'Erro ao fazer upload', description: error.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const mockSignDocument = async () => {
    await ServiceOrdersService.updateServiceOrder(id!, {
      customer_signature_url: 'https://img.usecurling.com/p/200/100?q=signature&color=black',
    })
    toast({ title: 'Assinatura Coletada', description: 'Assinatura salva com sucesso.' })
    loadOrderData()
  }

  const handleConsume = () => {
    if (!order?.contract_id) {
      toast({
        title: 'Aviso',
        description: 'Esta OS não possui contrato vinculado para apropriação de custos.',
        variant: 'destructive',
      })
      return
    }
    if (!selectedMaterial) {
      toast({ title: 'Aviso', description: 'Selecione um material.', variant: 'destructive' })
      return
    }
    try {
      consumeForOS(selectedMaterial, consumeQty, order.vehicle_id || undefined)

      const prod = products.find((p) => p.id === selectedMaterial)
      addCost({
        contractId: order.contract_id,
        category: 'material_os',
        value: (prod?.average_cost || 0) * consumeQty,
        date: new Date().toISOString().split('T')[0],
        description: `Consumo OS ${order.id.split('-')[0]}: ${consumeQty}x ${prod?.name}`,
        origin: 'os',
      })

      toast({
        title: 'Material Consumido',
        description: 'Estoque atualizado e custo gerado no contrato.',
      })
      setSelectedMaterial('')
      setConsumeQty(1)
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  if (loading) return <div className="p-8 text-center">Carregando...</div>
  if (!order) return null

  const availableProducts = products.filter((p) =>
    balances.some((b) => b.product_id === p.id && b.quantity > 0),
  )

  return (
    <div className="container max-w-4xl mx-auto p-4 space-y-6 animate-fade-in-up pb-20">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">OS #{order.id.split('-')[0]}</h1>
          <p className="text-muted-foreground">{order.description}</p>
        </div>
        <div className="flex items-center gap-3">
          {isAdmin && (
            <Button variant="destructive" size="sm" onClick={() => setShowDeleteAlert(true)}>
              <Trash2 className="w-4 h-4 mr-2" /> Excluir
            </Button>
          )}
          <Badge
            variant={order.status === 'in_progress' ? 'default' : 'secondary'}
            className="text-lg px-4 py-1"
          >
            {order.status.toUpperCase()}
          </Badge>
        </div>
      </div>

      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="p-6">
          <div className="flex gap-4 justify-center flex-wrap">
            {order.status === 'pending' && (
              <Button
                size="lg"
                onClick={() => handleStatusChange('scheduled')}
                className="w-40 bg-blue-600 hover:bg-blue-700"
              >
                Agendar
              </Button>
            )}
            {order.status === 'scheduled' && (
              <Button
                size="lg"
                onClick={() => handleStatusChange('deslocamento')}
                className="w-48 bg-purple-600 hover:bg-purple-700"
              >
                Iniciar Deslocamento
              </Button>
            )}
            {order.status === 'deslocamento' && (
              <Button size="lg" onClick={() => handleStatusChange('in_progress')} className="w-48">
                <Play className="mr-2 h-5 w-5" /> Iniciar Execução
              </Button>
            )}
            {order.status === 'in_progress' && (
              <>
                <Button
                  size="lg"
                  onClick={() => handleStatusChange('paused')}
                  className="w-40 bg-yellow-600 hover:bg-yellow-700"
                >
                  Pausar
                </Button>
                <Button
                  size="lg"
                  onClick={() => handleStatusChange('in_audit')}
                  className="w-48 bg-indigo-600 hover:bg-indigo-700"
                >
                  Enviar p/ Auditoria
                </Button>
              </>
            )}
            {order.status === 'paused' && (
              <Button
                size="lg"
                onClick={() => handleStatusChange('in_progress')}
                className="w-48 bg-blue-600 hover:bg-blue-700"
              >
                <Play className="mr-2 h-5 w-5" /> Retomar
              </Button>
            )}
            {order.status === 'in_audit' && (
              <>
                <Button
                  size="lg"
                  onClick={() => handleStatusChange('completed')}
                  className="w-48 bg-green-600 hover:bg-green-700"
                >
                  <CheckCircle2 className="mr-2 h-5 w-5" /> Aprovar (Finalizar)
                </Button>
                <Button
                  size="lg"
                  onClick={() => handleStatusChange('rejected')}
                  className="w-40 bg-red-600 hover:bg-red-700"
                >
                  Rejeitar
                </Button>
              </>
            )}
            {order.status === 'rejected' && (
              <Button
                size="lg"
                onClick={() => handleStatusChange('in_progress')}
                className="w-48 bg-yellow-600 hover:bg-yellow-700"
              >
                <Play className="mr-2 h-5 w-5" /> Retomar Execução
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="checklist" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="details">Detalhes</TabsTrigger>
          <TabsTrigger value="checklist">Checklist</TabsTrigger>
          <TabsTrigger value="materials">Materiais</TabsTrigger>
          <TabsTrigger value="photos">Fotos</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Informações Gerais</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-6">
              <div>
                <p className="text-sm font-medium text-muted-foreground">SLA Status</p>
                <Badge
                  variant={order.sla_status === 'breached' ? 'destructive' : 'outline'}
                  className="mt-1"
                >
                  {order.sla_status || 'N/A'}
                </Badge>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Tempo Total</p>
                <p className="text-xl font-semibold">{order.total_duration_minutes || 0} min</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="checklist" className="mt-4 space-y-4">
          {checklists.map((c) => (
            <Card key={c.id}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg">Checklist de Manutenção</CardTitle>
                  <Badge variant={c.status === 'completed' ? 'default' : 'secondary'}>
                    {c.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                {c.status !== 'completed' ? (
                  <Button
                    onClick={() => mockCompleteChecklist(c.id)}
                    className="w-full"
                    variant="outline"
                  >
                    <ClipboardList className="w-4 h-4 mr-2" /> Preencher Automaticamente (Mock)
                  </Button>
                ) : (
                  <p className="text-sm text-green-600 font-medium flex items-center">
                    <CheckCircle2 className="w-4 h-4 mr-2" /> Todas as respostas registradas
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="materials" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Consumo de Materiais do Estoque</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4 items-end">
                <div className="flex-1 w-full space-y-2">
                  <Label>Material Disponível</Label>
                  <Select value={selectedMaterial} onValueChange={setSelectedMaterial}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione..." />
                    </SelectTrigger>
                    <SelectContent>
                      {availableProducts.map((p) => {
                        const vBal =
                          balances.find(
                            (b) => b.product_id === p.id && b.location_id === order.vehicle_id,
                          )?.quantity || 0
                        const cBal =
                          balances.find(
                            (b) => b.product_id === p.id && b.location_type === 'central',
                          )?.quantity || 0
                        const total = vBal + cBal
                        return (
                          <SelectItem key={p.id} value={p.id}>
                            {p.name} ({total} disp. - V:{vBal} C:{cBal})
                          </SelectItem>
                        )
                      })}
                      {availableProducts.length === 0 && (
                        <SelectItem value="none" disabled>
                          Estoque vazio
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-full sm:w-24 space-y-2">
                  <Label>Qtd</Label>
                  <Input
                    type="number"
                    value={consumeQty}
                    onChange={(e) => setConsumeQty(Number(e.target.value))}
                    min={1}
                  />
                </div>
                <Button onClick={handleConsume} className="w-full sm:w-auto mt-2 sm:mt-0">
                  <Box className="w-4 h-4 mr-2" /> Consumir
                </Button>
              </div>
              <div className="text-xs text-muted-foreground mt-4 border-t pt-4">
                * O sistema tentará baixar primeiro o estoque do seu veículo, e caso falte, buscará
                do almoxarifado central.
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="photos" className="mt-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Evidências Fotográficas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-1 relative">
                  <Input
                    type="file"
                    accept="image/*"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    onChange={(e) => uploadPhoto(e, 'service_order_initial')}
                  />
                  <Button
                    variant={photos.some((p) => p.type === 'initial') ? 'secondary' : 'default'}
                    className="w-full pointer-events-none"
                  >
                    <Camera className="w-4 h-4 mr-2" /> Foto Inicial
                  </Button>
                </div>
                <div className="flex-1 relative">
                  <Input
                    type="file"
                    accept="image/*"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    onChange={(e) => uploadPhoto(e, 'service_order_final')}
                  />
                  <Button
                    variant={photos.some((p) => p.type === 'final') ? 'secondary' : 'default'}
                    className="w-full pointer-events-none"
                  >
                    <Camera className="w-4 h-4 mr-2" /> Foto Final
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                {photos.map((p) => (
                  <div
                    key={p.id}
                    className="relative aspect-video rounded-md overflow-hidden border"
                  >
                    <img
                      src={p.storage_url}
                      alt="Evidência"
                      className="object-cover w-full h-full"
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-black/60 p-1 text-xs text-white text-center">
                      {p.type === 'initial' ? 'Foto Inicial' : 'Foto Final'}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Assinatura do Cliente</CardTitle>
            </CardHeader>
            <CardContent>
              {!order.customer_signature_url ? (
                <Button onClick={mockSignDocument} variant="outline" className="w-full">
                  <PenTool className="w-4 h-4 mr-2" /> Coletar Assinatura (Mock)
                </Button>
              ) : (
                <div className="border rounded-md p-4 bg-white flex justify-center">
                  <img
                    src={order.customer_signature_url}
                    alt="Assinatura"
                    className="h-20 mix-blend-multiply"
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <AlertDialog open={showDeleteAlert} onOpenChange={setShowDeleteAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Ordem de Serviço</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza de que deseja excluir esta OS? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault()
                handleDelete()
              }}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
