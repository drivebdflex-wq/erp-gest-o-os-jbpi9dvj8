CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 5. RESOURCE MANAGEMENT
-- ==========================================
=======
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN ticket_number VARCHAR(100); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN dependency VARCHAR(255); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN agency_code VARCHAR(100); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN os_type VARCHAR(100); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN warranty BOOLEAN DEFAULT false; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN opening_date TIMESTAMP WITH TIME ZONE; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN acceptance_date TIMESTAMP WITH TIME ZONE; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN client_request TEXT; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN procedures_executed TEXT; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN pending_issues TEXT; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN risks_found TEXT; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN general_observations TEXT; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN technical_recommendations TEXT; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN operational_checklist TEXT; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN supervisor_id UUID REFERENCES users(id) ON DELETE SET NULL; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN vehicle_used VARCHAR(255); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN tools_used TEXT; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN displacement_time INT; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN discount DECIMAL(12, 2) DEFAULT 0; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN client_signature_name VARCHAR(255); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN client_signature_position VARCHAR(255); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN internal_code VARCHAR(100); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN billing_type VARCHAR(100); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN supervisor_approval BOOLEAN DEFAULT false; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN client_approval BOOLEAN DEFAULT false; EXCEPTION WHEN duplicate_column THEN null; END $$;
-- 5. RESOURCE MANAGEMENT
=======
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN is_billed BOOLEAN DEFAULT false; EXCEPTION WHEN duplicate_column THEN null; END $$;

DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN sector VARCHAR(255); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN reference_point VARCHAR(255); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN root_cause TEXT; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN supervisor_signature_url VARCHAR(1024); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN km_driven DECIMAL(10, 2); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN floor VARCHAR(100); EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN address TEXT; EXCEPTION WHEN duplicate_column THEN null; END $$;
DO $$ BEGIN ALTER TABLE service_orders ADD COLUMN order_number VARCHAR(100); EXCEPTION WHEN duplicate_column THEN null; END $$;

-- ==========================================
-- 5. RESOURCE MANAGEMENT==========================================
-- 5. RESOURCE MANAGEMENT
-- ====================================================================================
-- ENUMS
-- ==========================================

DO $ BEGIN CREATE TYPE service_order_status AS ENUM ('draft', 'pending', 'scheduled', 'deslocamento', 'in_progress', 'paused', 'in_audit', 'completed', 'rejected', 'cancelled'); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN ALTER TYPE service_order_status ADD VALUE IF NOT EXISTS 'deslocamento'; EXCEPTION WHEN OTHERS THEN null; END $;
DO $ BEGIN CREATE TYPE service_order_priority AS ENUM ('low', 'medium', 'high', 'urgent'); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TYPE service_order_service_type AS ENUM ('eletrica', 'hidraulica', 'civil', 'climatizacao', 'preventiva', 'corretiva', 'pintura', 'estrutural', 'facilities', 'infraestrutura', 'limpeza_tecnica', 'vistoria', 'emergencial', 'serralheria', 'marmoraria', 'marcenaria'); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN ALTER TYPE service_order_service_type ADD VALUE IF NOT EXISTS 'climatizacao'; EXCEPTION WHEN OTHERS THEN null; END $;
DO $ BEGIN ALTER TYPE service_order_service_type ADD VALUE IF NOT EXISTS 'preventiva'; EXCEPTION WHEN OTHERS THEN null; END $;
DO $ BEGIN ALTER TYPE service_order_service_type ADD VALUE IF NOT EXISTS 'corretiva'; EXCEPTION WHEN OTHERS THEN null; END $;
DO $ BEGIN ALTER TYPE service_order_service_type ADD VALUE IF NOT EXISTS 'pintura'; EXCEPTION WHEN OTHERS THEN null; END $;
DO $ BEGIN ALTER TYPE service_order_service_type ADD VALUE IF NOT EXISTS 'estrutural'; EXCEPTION WHEN OTHERS THEN null; END $;
DO $ BEGIN ALTER TYPE service_order_service_type ADD VALUE IF NOT EXISTS 'facilities'; EXCEPTION WHEN OTHERS THEN null; END $;
DO $ BEGIN ALTER TYPE service_order_service_type ADD VALUE IF NOT EXISTS 'infraestrutura'; EXCEPTION WHEN OTHERS THEN null; END $;
DO $ BEGIN ALTER TYPE service_order_service_type ADD VALUE IF NOT EXISTS 'limpeza_tecnica'; EXCEPTION WHEN OTHERS THEN null; END $;
DO $ BEGIN ALTER TYPE service_order_service_type ADD VALUE IF NOT EXISTS 'vistoria'; EXCEPTION WHEN OTHERS THEN null; END $;
DO $ BEGIN ALTER TYPE service_order_service_type ADD VALUE IF NOT EXISTS 'emergencial'; EXCEPTION WHEN OTHERS THEN null; END $;
DO $ BEGIN CREATE TYPE sla_status AS ENUM ('within_sla', 'warning', 'breached'); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TYPE checklist_status AS ENUM ('pending', 'in_progress', 'completed'); EXCEPTION WHEN duplicate_object THEN null; END $;

-- ==========================================
-- 1. CORE ACCESS CONTROL
-- ==========================================

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

DO $$ BEGIN
  ALTER TABLE users ADD COLUMN avatar_url TEXT;
EXCEPTION
  WHEN duplicate_column THEN
    ALTER TABLE users ALTER COLUMN avatar_url TYPE TEXT;
END $$;

CREATE TABLE IF NOT EXISTS roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_roles (
    user_id UUID REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE,
    role_id UUID REFERENCES roles(id) ON DELETE CASCADE ON UPDATE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, role_id)
);

CREATE TABLE IF NOT EXISTS company_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_name VARCHAR(255) NOT NULL DEFAULT 'FieldOps Pro',
    logo_url VARCHAR(1024),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 2. OPERATIONAL MANAGEMENT
-- ==========================================

CREATE TABLE IF NOT EXISTS teams (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    supervisor_id UUID REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS technicians (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE,
    team_id UUID REFERENCES teams(id) ON DELETE SET NULL ON UPDATE CASCADE,
    specialty VARCHAR(255),
    availability_status VARCHAR(50) DEFAULT 'available',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 3. CLIENT & CONTRACT INFRASTRUCTURE
-- ==========================================

CREATE TABLE IF NOT EXISTS clients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    document VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255),
    phone VARCHAR(50),
    address TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS contracts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE ON UPDATE CASCADE,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL CHECK (type IN ('Manutenção', 'Obra')),
    contract_number VARCHAR(100),
    location VARCHAR(255),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    value DECIMAL(12, 2),
    last_adjustment_date DATE,
    next_adjustment_date DATE,
    adjustment_type VARCHAR(50),
    adjustment_percentage DECIMAL(5, 2),
    allows_corrective BOOLEAN DEFAULT true,
    has_preventive BOOLEAN DEFAULT false,
    preventive_frequency VARCHAR(50),
    sla_default INT,
    attachment_url VARCHAR(1024),
    terms TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS contract_units (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    contract_id UUID NOT NULL REFERENCES contracts(id) ON DELETE CASCADE ON UPDATE CASCADE,
    prefix VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(2) NOT NULL,
    responsible_name VARCHAR(255) NOT NULL,
    responsible_phone VARCHAR(50),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(contract_id, prefix)
);

CREATE TABLE IF NOT EXISTS contract_price_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    contract_id UUID NOT NULL REFERENCES contracts(id) ON DELETE CASCADE ON UPDATE CASCADE,
    service_code VARCHAR(50) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    unit_price DECIMAL(12, 2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(contract_id, service_code)
);

-- ==========================================
-- 4. SERVICE ORDER LIFECYCLE
-- ==========================================

CREATE TABLE IF NOT EXISTS service_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE ON UPDATE CASCADE,
    contract_id UUID REFERENCES contracts(id) ON DELETE SET NULL ON UPDATE CASCADE,
    unit_id UUID REFERENCES contract_units(id) ON DELETE RESTRICT ON UPDATE CASCADE,
    technician_id UUID REFERENCES technicians(id) ON DELETE SET NULL ON UPDATE CASCADE,
    status service_order_status NOT NULL DEFAULT 'pending',
    priority service_order_priority NOT NULL DEFAULT 'medium',
    service_type service_order_service_type NOT NULL DEFAULT 'civil',
    description TEXT,
    service_code VARCHAR(50),
    service_value DECIMAL(12, 2),
    
    -- Schedule & Deadlines
    scheduled_at TIMESTAMP WITH TIME ZONE,
    deadline_at TIMESTAMP WITH TIME ZONE,
    sla_status sla_status DEFAULT 'within_sla',
    
    -- Execution Time Tracking
    started_at TIMESTAMP WITH TIME ZONE,
    last_resumed_at TIMESTAMP WITH TIME ZONE,
    paused_at TIMESTAMP WITH TIME ZONE,
    finished_at TIMESTAMP WITH TIME ZONE,
    total_duration_minutes INT DEFAULT 0,
    estimated_duration_minutes INT DEFAULT 60,
    
    -- Spatial Data
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    
    -- New Facilities Fields
    diagnostics TEXT,
    cost_center VARCHAR(100),
    billing_status VARCHAR(50) DEFAULT 'pending',
    approval_status VARCHAR(50) DEFAULT 'pending',
    technician_signature_url VARCHAR(1024),
    client_signature_url VARCHAR(1024),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 5. RESOURCE MANAGEMENT
-- ==========================================

CREATE TABLE IF NOT EXISTS materials (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    unit_type VARCHAR(50),
    sku VARCHAR(100) UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inventory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    material_id UUID NOT NULL REFERENCES materials(id) ON DELETE CASCADE ON UPDATE CASCADE,
    quantity INT NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    location VARCHAR(255),
    min_stock_level INT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS service_order_materials (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_order_id UUID NOT NULL REFERENCES service_orders(id) ON DELETE CASCADE ON UPDATE CASCADE,
    material_id UUID NOT NULL REFERENCES materials(id) ON DELETE CASCADE ON UPDATE CASCADE,
    quantity_used INT NOT NULL CHECK (quantity_used > 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vehicles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plate VARCHAR(20) NOT NULL UNIQUE,
    model VARCHAR(255),
    brand VARCHAR(255),
    technician_id UUID REFERENCES technicians(id) ON DELETE SET NULL ON UPDATE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 6. QUALITY & COMPLIANCE
-- ==========================================

CREATE TABLE IF NOT EXISTS checklists (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    created_by UUID REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS checklist_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    checklist_id UUID NOT NULL REFERENCES checklists(id) ON DELETE CASCADE ON UPDATE CASCADE,
    label VARCHAR(255) NOT NULL,
    field_type VARCHAR(50) NOT NULL,
    is_required BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS service_order_checklists (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_order_id UUID NOT NULL REFERENCES service_orders(id) ON DELETE CASCADE ON UPDATE CASCADE,
    checklist_id UUID NOT NULL REFERENCES checklists(id) ON DELETE CASCADE ON UPDATE CASCADE,
    status checklist_status DEFAULT 'pending',
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS checklist_responses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_order_checklist_id UUID NOT NULL REFERENCES service_order_checklists(id) ON DELETE CASCADE ON UPDATE CASCADE,
    checklist_item_id UUID NOT NULL REFERENCES checklist_items(id) ON DELETE CASCADE ON UPDATE CASCADE,
    response_text TEXT,
    response_boolean BOOLEAN,
    response_number DECIMAL,
    photo_url VARCHAR(1024),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS photos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_order_id UUID NOT NULL REFERENCES service_orders(id) ON DELETE CASCADE ON UPDATE CASCADE,
    type VARCHAR(50) NOT NULL CHECK (type IN ('initial', 'final')),
    storage_url VARCHAR(1024) NOT NULL,
    uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS service_order_attachments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_order_id UUID NOT NULL REFERENCES service_orders(id) ON DELETE CASCADE ON UPDATE CASCADE,
    file_name VARCHAR(255) NOT NULL,
    file_url VARCHAR(1024) NOT NULL,
    uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 7. TRACEABILITY
-- ==========================================

CREATE TABLE IF NOT EXISTS audits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_name VARCHAR(255) NOT NULL,
    record_id UUID NOT NULL,
    action VARCHAR(50) NOT NULL,
    old_value JSONB,
    new_value JSONB,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    user_name VARCHAR(255),
    action VARCHAR(50) NOT NULL,
    table_name VARCHAR(255) NOT NULL,
    record_id UUID NOT NULL,
    old_value JSONB,
    new_value JSONB,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS deleted_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_name VARCHAR(255) NOT NULL,
    record_id UUID NOT NULL,
    data JSONB NOT NULL,
    deleted_by UUID REFERENCES users(id) ON DELETE SET NULL,
    deleted_by_name VARCHAR(255),
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    level VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    context JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- TRIGGERS FOR UPDATED_AT
-- ==========================================

CREATE OR REPLACE FUNCTION trigger_set_timestamp()
RETURNS TRIGGER AS $
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$ LANGUAGE plpgsql;

DO $ BEGIN CREATE TRIGGER set_timestamp_users BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_company_settings BEFORE UPDATE ON company_settings FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_roles BEFORE UPDATE ON roles FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_user_roles BEFORE UPDATE ON user_roles FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_teams BEFORE UPDATE ON teams FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_technicians BEFORE UPDATE ON technicians FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_clients BEFORE UPDATE ON clients FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_contracts BEFORE UPDATE ON contracts FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_contract_units BEFORE UPDATE ON contract_units FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_contract_price_items BEFORE UPDATE ON contract_price_items FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_service_orders BEFORE UPDATE ON service_orders FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_materials BEFORE UPDATE ON materials FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_inventory BEFORE UPDATE ON inventory FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_service_order_materials BEFORE UPDATE ON service_order_materials FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_vehicles BEFORE UPDATE ON vehicles FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_checklists BEFORE UPDATE ON checklists FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_checklist_items BEFORE UPDATE ON checklist_items FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_service_order_checklists BEFORE UPDATE ON service_order_checklists FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_checklist_responses BEFORE UPDATE ON checklist_responses FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_photos BEFORE UPDATE ON photos FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_service_order_attachments BEFORE UPDATE ON service_order_attachments FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_audits BEFORE UPDATE ON audits FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;
DO $ BEGIN CREATE TRIGGER set_timestamp_logs BEFORE UPDATE ON logs FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp(); EXCEPTION WHEN duplicate_object THEN null; END $;

-- ==========================================
-- AUDIT TRIGGER FOR SERVICE ORDERS
-- ==========================================

CREATE OR REPLACE FUNCTION audit_service_order_status_change()
RETURNS TRIGGER AS $
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO audits (table_name, record_id, action, old_value, new_value)
    VALUES (
      'service_orders',
      NEW.id,
      'UPDATE',
      jsonb_build_object('status', OLD.status::text),
      jsonb_build_object('status', NEW.status::text)
    );
  END IF;
  RETURN NEW;
END;
$ LANGUAGE plpgsql;

DO $ BEGIN
    CREATE TRIGGER audit_service_order_status
    AFTER UPDATE ON service_orders
    FOR EACH ROW
    EXECUTE FUNCTION audit_service_order_status_change();
EXCEPTION WHEN duplicate_object THEN null; END $;

-- ==========================================
-- INDEXING STRATEGY
-- ==========================================

CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role_id ON user_roles(role_id);
CREATE INDEX IF NOT EXISTS idx_teams_supervisor_id ON teams(supervisor_id);
CREATE INDEX IF NOT EXISTS idx_technicians_user_id ON technicians(user_id);
CREATE INDEX IF NOT EXISTS idx_technicians_team_id ON technicians(team_id);
CREATE INDEX IF NOT EXISTS idx_contracts_client_id ON contracts(client_id);
CREATE INDEX IF NOT EXISTS idx_contract_units_contract_id ON contract_units(contract_id);
CREATE INDEX IF NOT EXISTS idx_contract_price_items_contract_id ON contract_price_items(contract_id);
CREATE INDEX IF NOT EXISTS idx_service_orders_client_id ON service_orders(client_id);
CREATE INDEX IF NOT EXISTS idx_service_orders_contract_id ON service_orders(contract_id);
CREATE INDEX IF NOT EXISTS idx_service_orders_unit_id ON service_orders(unit_id);
CREATE INDEX IF NOT EXISTS idx_service_orders_technician_id ON service_orders(technician_id);
CREATE INDEX IF NOT EXISTS idx_inventory_material_id ON inventory(material_id);
CREATE INDEX IF NOT EXISTS idx_so_materials_so_id ON service_order_materials(service_order_id);
CREATE INDEX IF NOT EXISTS idx_so_materials_material_id ON service_order_materials(material_id);
CREATE INDEX IF NOT EXISTS idx_vehicles_technician_id ON vehicles(technician_id);
CREATE INDEX IF NOT EXISTS idx_checklists_created_by ON checklists(created_by);
CREATE INDEX IF NOT EXISTS idx_checklist_items_checklist_id ON checklist_items(checklist_id);
CREATE INDEX IF NOT EXISTS idx_so_checklists_so_id ON service_order_checklists(service_order_id);
CREATE INDEX IF NOT EXISTS idx_so_checklists_checklist_id ON service_order_checklists(checklist_id);
CREATE INDEX IF NOT EXISTS idx_checklist_responses_so_chk_id ON checklist_responses(service_order_checklist_id);
CREATE INDEX IF NOT EXISTS idx_photos_service_order_id ON photos(service_order_id);
CREATE INDEX IF NOT EXISTS idx_photos_uploaded_by ON photos(uploaded_by);
CREATE INDEX IF NOT EXISTS idx_so_attachments_so_id ON service_order_attachments(service_order_id);
CREATE INDEX IF NOT EXISTS idx_audits_user_id ON audits(user_id);

CREATE INDEX IF NOT EXISTS idx_service_orders_status ON service_orders(status);
CREATE INDEX IF NOT EXISTS idx_service_orders_priority ON service_orders(priority);
CREATE INDEX IF NOT EXISTS idx_service_orders_service_type ON service_orders(service_type);
CREATE INDEX IF NOT EXISTS idx_service_orders_sla_status ON service_orders(sla_status);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_clients_document ON clients(document);

-- ==========================================
-- OPERATIONAL EXAMPLES (SEED DATA)
-- ==========================================

INSERT INTO roles (id, name, description) VALUES ('11111111-1111-1111-1111-111111111111', 'Administrator', 'Full system access') ON CONFLICT (name) DO NOTHING;
INSERT INTO users (id, name, email, password_hash) VALUES ('22222222-2222-2222-2222-222222222222', 'Admin User', 'admin@example.com', 'hashed_pwd_123') ON CONFLICT (email) DO NOTHING;
INSERT INTO user_roles (user_id, role_id) VALUES ('22222222-2222-2222-2222-222222222222', '11111111-1111-1111-1111-111111111111') ON CONFLICT (user_id, role_id) DO NOTHING;

INSERT INTO clients (id, name, document, email, phone, address)
VALUES ('33333333-3333-3333-3333-333333333333', 'Acme Corporation', '12.345.678/0001-90', 'contact@acme.com', '555-0199', '123 Business Avenue')
ON CONFLICT (document) DO NOTHING;

INSERT INTO contracts (id, client_id, name, type, contract_number, location, start_date, end_date, value)
VALUES ('77777777-7777-7777-7777-777777777777', '33333333-3333-3333-3333-333333333333', 'Manutenção Predial Alpha', 'Manutenção', 'CT-2023-001', 'Sede Principal', '2023-01-01', CURRENT_DATE + INTERVAL '15 days', 15000)
ON CONFLICT (id) DO NOTHING;

INSERT INTO contract_units (id, contract_id, prefix, name, address, city, state, responsible_name, responsible_phone)
VALUES ('88888888-8888-8888-8888-888888888888', '77777777-7777-7777-7777-777777777777', '001', 'Agência Centro', 'Rua Principal, 100', 'São Paulo', 'SP', 'João Silva', '11999999999')
ON CONFLICT (contract_id, prefix) DO NOTHING;

INSERT INTO contract_price_items (contract_id, service_code, service_name, unit_price)
VALUES 
('77777777-7777-7777-7777-777777777777', '001', 'Troca de lâmpada', 50.00),
('77777777-7777-7777-7777-777777777777', '002', 'Manutenção elétrica', 120.00)
ON CONFLICT (contract_id, service_code) DO NOTHING;

INSERT INTO technicians (id, user_id, specialty)
VALUES ('44444444-4444-4444-4444-444444444444', '22222222-2222-2222-2222-222222222222', 'General Maintenance')
ON CONFLICT (id) DO NOTHING;

INSERT INTO service_orders (id, client_id, contract_id, unit_id, technician_id, status, priority, service_type, description, scheduled_at, deadline_at, sla_status, latitude, longitude, estimated_duration_minutes)
VALUES (
    '55555555-5555-5555-5555-555555555555', 
    '33333333-3333-3333-3333-333333333333', 
    '77777777-7777-7777-7777-777777777777',
    '88888888-8888-8888-8888-888888888888',
    '44444444-4444-4444-4444-444444444444', 
    'pending', 
    'high', 
    'eletrica',
    'Annual HVAC maintenance and inspection.', 
    CURRENT_TIMESTAMP + INTERVAL '2 days',
    CURRENT_TIMESTAMP + INTERVAL '3 days',
    'within_sla',
    -23.5505,
    -46.6333,
    120
)
ON CONFLICT (id) DO NOTHING;
